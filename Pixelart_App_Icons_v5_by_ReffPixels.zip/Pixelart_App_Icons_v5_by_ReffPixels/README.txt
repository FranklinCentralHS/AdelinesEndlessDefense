IMPORTANT: Pixelart Icon Pack by @ReffPixels (Pablo Rodriguez) is a free asset pack for non-commercial personal use only. This asset pack should never be resold, distributed or used within a commercial project. This asset pack is meant for personal use ONLY. Use at your own discretion.

Thank you for downloading this asset pack. If you need anything, or if there is something wrong with your download please contact me through any of the following means:

Portfolio: https://www.reffpixels.com/
Email: reffpixels@gmail.com

Twitter: https://twitter.com/reffpixels
Itch.io: https://reffpixels.itch.io/
Reddit: https://www.reddit.com/user/_Reff/
Discord: reffpixels

I'm also reffpixels in (most) social media, but the previous contact methods are preferable.

